package com.example.myapplication10;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public void signUp(View view) {
        EditText FirstName = (EditText) findViewById(R.id.firstnamebtn);
        EditText LastName = (EditText) findViewById(R.id.lastnamebtn);
        EditText age = (EditText) findViewById(R.id.agebtn);
        int Age = Integer.parseInt(age.getText().toString());
        if (FirstName.getText().toString().isEmpty()) {
            Toast.makeText(this, "Write your Firstname!", Toast.LENGTH_SHORT).show();
        } else if (LastName.getText().toString().isEmpty()) {
            Toast.makeText(this, "Write your Lastname", Toast.LENGTH_SHORT).show();
        } else if (age.getText().toString().isEmpty()) {
            Toast.makeText(this, "Write your age", Toast.LENGTH_SHORT).show();
        } else if (Age <= 1) {
            Toast.makeText(this, "Write your real age", Toast.LENGTH_SHORT).show();
        }else if (Age < 18) {
                Toast.makeText(this, "Your age is under 18!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "You registered succesfully", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public class User {

        private String firstName = null;
        private String lastName = null;
        private int birthYear = 0;


        public User(String first,
                    String last,
                    int year) {

            firstName = first;
            lastName = last;
            birthYear = year;

        }
    }

}